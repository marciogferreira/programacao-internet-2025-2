import express from "express";
import UsuarioRoute from "./src/routes/UsuarioRoute.js";
import cors from 'cors'

const app = express()

app.use(express.json())

app.use(cors({
    origin: '*'
}))
app.get('/', (req, res) => {
    res.send("Hello Servidor NodeJs ADS 42 e 52")
})

app.use(UsuarioRoute)

app.listen(3000, () => {
    console.log("Servidor executando na PORTA 3000")
})