import UsuarioModel from '../models/UsuarioModel.js'
const UsuarioController = {

    findAll: async (req, res) => {
        const dados = await UsuarioModel.findAll()
        return res.json(dados)
    },
    findByPk: async (req, res) => {
        const id = req.params.id
        const dados = await UsuarioModel.findByPk(id)
        return res.json(dados)
    },
    create: async (req, res) => {
        const data = req.body;
        const dados = await UsuarioModel.create(data)
        return res.json(dados)
    },
    update: async (req, res) => {
        const data = req.body;
        const id = req.params.id
        const dados = await UsuarioModel.update(data, {
            where: {
                id: id
            }
        })
        return res.json(dados)
    },
    
    delete: async (req, res) => {
        const id = req.params.id
        const dados = await UsuarioModel.destroy({
            where: {
                id: id
            }
        })
        return res.json(dados)
    }
}

export default UsuarioController;