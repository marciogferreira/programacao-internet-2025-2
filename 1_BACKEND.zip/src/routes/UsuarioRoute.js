import express from "express";
import UsuarioController from "../controllers/UsuarioController.js";

const UsuarioRoute = express.Router()

UsuarioRoute.get('/usuarios', UsuarioController.findAll)
UsuarioRoute.get('/usuarios/:id', UsuarioController.findByPk)
UsuarioRoute.post('/usuarios', UsuarioController.create)
UsuarioRoute.put('/usuarios/:id', UsuarioController.update)
UsuarioRoute.delete('/usuarios/:id', UsuarioController.delete)

export default UsuarioRoute;