import Conexao from "../config/conexao.js";

import UsuarioModel from "../models/UsuarioModel.js";
import ClienteModel from "../models/ClienteModel.js";

Conexao.sync({ force: false });