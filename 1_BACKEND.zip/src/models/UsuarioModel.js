import { DataTypes } from "sequelize";
import Conexao from "../config/conexao.js";

const UsuarioModel = Conexao.define(
    "UsuarioModel",
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        nome: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        email: {
            type: DataTypes.STRING(255),
            allowNull: false,
            unique: true
        },
        senha: {
            type: DataTypes.STRING,
            allowNull: false
        }
    },
    {
        tableName: 'usuarios'
    }
);

export default UsuarioModel;

// UsuarioModel.create(data)
// UsuarioModel.update(data)
// UsuarioModel.find()
// UsuarioModel.destroy()