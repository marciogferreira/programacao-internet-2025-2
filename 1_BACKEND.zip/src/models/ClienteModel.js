import { DataTypes } from "sequelize";
import Conexao from "../config/conexao.js";

const ClienteModel = Conexao.define(
    "ClienteModel",
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        nome: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        email: {
            type: DataTypes.STRING(255),
            allowNull: false,
            unique: true
        }
    },
    {
        tableName: 'clientes'
    }
);

export default ClienteModel;

// UsuarioModel.create(data)
// UsuarioModel.update(data)
// UsuarioModel.find()
// UsuarioModel.destroy()