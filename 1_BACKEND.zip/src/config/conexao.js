import { Sequelize } from "sequelize";

const Conexao = new Sequelize({
    dialect: 'mysql',
    host: 'localhost',
    port: 3307,
    database: 'ads052',
    username: 'root',
    password: ''
});

export default Conexao