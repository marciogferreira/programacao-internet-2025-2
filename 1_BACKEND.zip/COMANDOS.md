NODEJS

01 CRIANDO O PACKAGE.JSON - GERENCIADOR DE DEPENDENCIAS
EXECUTE: npm init -y

02 INSTALANDO BIBLIOTECAS
EXECUTE: 

npm install express
npm install nodemon
npm install --save sequelize
npm install --save mysql2
npm i cors


CRIANDO AS TABELAS NO BANCO:
Execute:
node Migration.js

